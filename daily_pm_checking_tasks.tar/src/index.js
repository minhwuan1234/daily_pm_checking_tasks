require('dotenv').config();

async function main() {
  const rawPayload = process.env.PAYLOAD;

  if (!rawPayload) {
    console.error('❌ Không có PAYLOAD từ GitHub Actions');
    process.exit(1);
  }

  let payload;
  try {
    payload = JSON.parse(rawPayload);
  } catch (e) {
    console.error('❌ PAYLOAD không phải JSON hợp lệ:', e.message);
    process.exit(1);
  }

  const { date, totalMembers, totalTasks, members } = payload;

  console.log('✅ Nhận data từ n8n thành công');
  console.log(`📅 Ngày: ${date}`);
  console.log(`👥 Số thành viên có task: ${totalMembers}`);
  console.log(`📋 Tổng số task: ${totalTasks}`);
  console.log('─'.repeat(50));

  for (const m of members) {
    console.log(`\n👤 ${m.member} — ${m.taskCount} task`);
    console.log(`   ${m.tasksSummary.replace(/\n/g, '\n   ')}`);
  }

  console.log('\n─'.repeat(50));
  console.log('✅ Parse payload hoàn tất — sẵn sàng cho bước tiếp theo');

  // TODO: các bước tiếp theo
  // 1. lark/auth.js     → lấy access token
  // 2. lark/tasks.js    → search task by title
  // 3. lark/comments.js → lấy comments
  // 4. ai/claude.js     → tóm tắt + đề xuất
  // 5. notify/lark.js   → gửi PM
}

main().catch(err => {
  console.error('❌ Lỗi:', err.message);
  process.exit(1);
});
