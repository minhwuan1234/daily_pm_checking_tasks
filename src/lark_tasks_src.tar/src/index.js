require('dotenv').config();
const { searchTasks, getTaskDetail } = require('./lark/tasks');
const { getRecentComments }          = require('./lark/comments');

async function main() {
  // ── Nhận payload từ GitHub Actions ──────────────────────────
  const payload = JSON.parse(process.env.PAYLOAD || '{}');
  const { date, members = [] } = payload;

  console.log(`📅 Ngày: ${date}`);
  console.log(`👥 Số thành viên: ${members.length}\n`);

  const report = [];

  // ── Với mỗi thành viên → từng task của họ ───────────────────
  for (const m of members) {
    console.log(`\n👤 ${m.member}`);
    const memberReport = { member: m.member, tasks: [] };

    for (const t of m.tasks) {
      console.log(`  🔍 Tìm task: "${t.task.slice(0, 60)}..."`);

      // 1. Search task trên Lark theo keyword
      const matched = await searchTasks(t.task);

      if (matched.length === 0) {
        console.log(`  ⚠️  Không tìm thấy task trên Lark`);
        memberReport.tasks.push({
          taskName: t.task,
          larkFound: false,
        });
        continue;
      }

      // Lấy task khớp nhất (first match)
      const larkTask = matched[0];
      console.log(`  ✅ Tìm thấy: "${larkTask.summary}"`);

      // 2. Lấy task detail
      const detail = await getTaskDetail(larkTask.guid);

      // 3. Lấy comments trong 24h
      const comments = await getRecentComments(larkTask.guid);
      console.log(`  💬 Comments 24h: ${comments.length}`);

      memberReport.tasks.push({
        taskName:    t.task,
        larkTitle:   detail.title,
        status:      detail.status,
        due:         detail.due,
        description: detail.description,
        url:         detail.url,
        comments,
        larkFound:   true,
      });
    }

    report.push(memberReport);
  }

  // ── In report để verify ──────────────────────────────────────
  console.log('\n' + '═'.repeat(60));
  console.log('📋 REPORT TỔNG HỢP:');
  console.log(JSON.stringify(report, null, 2));

  // TODO: bước tiếp
  // → ai/claude.js  : gửi report vào Claude để tóm tắt
  // → notify/lark.js: gửi summary cho PM
}

main().catch(err => {
  console.error('❌ Lỗi:', err.message);
  process.exit(1);
});
