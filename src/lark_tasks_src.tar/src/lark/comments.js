const axios = require('axios');
const { getAccessToken } = require('./auth');

const BASE = 'https://open.larksuite.com/open-apis';

// Lấy comments của task, chỉ giữ lại comments trong 24h gần nhất
async function getRecentComments(taskId) {
  const token = await getAccessToken();

  const res = await axios.get(`${BASE}/task/v2/tasks/${taskId}/comments`, {
    headers: { Authorization: `Bearer ${token}` },
    params:  { page_size: 100 },
  });

  const comments = res.data?.data?.items || [];

  // Filter chỉ lấy comments trong 24h
  const since = Date.now() - 24 * 60 * 60 * 1000;

  const recent = comments
    .filter(c => {
      const ts = parseInt(c.created_at) * 1000;
      return ts >= since;
    })
    .map(c => ({
      author:    c.creator?.id || 'unknown',
      text:      extractText(c.content),
      createdAt: new Date(parseInt(c.created_at) * 1000)
                   .toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh' }),
    }))
    .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));

  return recent;
}

// Extract plain text từ Lark rich text content
function extractText(content) {
  if (!content) return '';
  try {
    const parsed = JSON.parse(content);
    // Lark content là array of blocks
    return parsed
      .map(block => (block.body?.elements || [])
        .map(el => el.text_run?.content || '')
        .join('')
      )
      .join('\n')
      .trim();
  } catch {
    // Nếu không parse được → trả về raw string
    return String(content).trim();
  }
}

module.exports = { getRecentComments };
